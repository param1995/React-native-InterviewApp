// src/screens/RecordAnswer.js
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Alert,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
} from "react-native";
import { Audio } from "expo-av";
import { storage } from "../services/storage";
import { v4 as uuidv4 } from "uuid";

const { width, height } = Dimensions.get("window");
const wp = (percentage) => (width * percentage) / 100;
const hp = (percentage) => (height * percentage) / 100;

const isTablet = width >= 768;
const isDesktop = width >= 1024;
const isSmallPhone = width < 375;

export default function RecordAnswer({ route, navigation }) {
  const { interview } = route.params;
  const [recording, setRecording] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [recordingStates, setRecordingStates] = useState({});
  const [sound, setSound] = useState(null);
  const [isRecordingSupported, setIsRecordingSupported] = useState(true);

  useEffect(() => {
    const setupAudio = async () => {
      try {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: true,
          interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
          playsInSilentModeIOS: true,
          shouldDuckAndroid: true,
          interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
          playThroughEarpieceAndroid: false,
        });

        const permission = await Audio.getPermissionsAsync();
        setIsRecordingSupported(permission.status === "granted" || permission.canAskAgain);
      } catch (error) {
        console.warn("Audio setup failed:", error);
        setIsRecordingSupported(false);
      }
    };

    setupAudio();

    return () => {
      if (sound) sound.unloadAsync();
    };
  }, []);

  async function startRecording(questionIndex) {
    try {
      if (recording) await stopRecording();

      const { status } = await Audio.requestPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Permission Required",
          "Microphone access is required to record answers."
        );
        return;
      }

      const rec = new Audio.Recording();
      await rec.prepareToRecordAsync(Audio.RECORDING_OPTIONS_PRESET_HIGH_QUALITY);
      await rec.startAsync();

      setRecording(rec);
      setCurrentQuestionIndex(questionIndex);
      setRecordingStates(prev => ({ ...prev, [questionIndex]: "recording" }));
    } catch (e) {
      console.error("Recording start error:", e);
      Alert.alert("Recording Error", e.message);
    }
  }

  async function stopRecording() {
    try {
      if (!recording) return;

      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      setRecording(null);
      setRecordingStates(prev => ({ ...prev, [currentQuestionIndex]: "recorded" }));

      if (!uri) return Alert.alert("Recording failed. Try again.");

      const existingIndex = answers.findIndex(a => a.qIndex === currentQuestionIndex);
      if (existingIndex !== -1) {
        setAnswers(prev =>
          prev.map((ans, i) =>
            i === existingIndex ? { ...ans, uri, recordedAt: Date.now() } : ans
          )
        );
      } else {
        setAnswers(prev => [
          ...prev,
          { id: uuidv4(), qIndex: currentQuestionIndex, uri, recordedAt: Date.now() }
        ]);
      }

      setCurrentQuestionIndex(null);
    } catch (e) {
      console.error("Stop recording error:", e);
      setRecording(null);
      setCurrentQuestionIndex(null);
      Alert.alert("Recording Error", "Failed to stop recording.");
    }
  }

  async function playRecording(uri) {
    try {
      if (sound) await sound.unloadAsync();
      const { sound: newSound } = await Audio.Sound.createAsync({ uri });
      setSound(newSound);
      await newSound.playAsync();
    } catch (e) {
      console.error("Playback error:", e);
      Alert.alert("Playback Error", "Failed to play recording.");
    }
  }

  async function submitAnswers() {
    try {
      const subs = await storage.getSubmissions();
      subs.push({
        id: uuidv4(),
        interviewId: interview.id,
        candidateId: "candidate@test.com",
        submittedAt: Date.now(),
        answers,
      });
      await storage.saveSubmissions(subs);
      Alert.alert("Success!", "Answers submitted successfully!", [
        { text: "OK", onPress: () => navigation.goBack() },
      ]);
    } catch (e) {
      console.error("Submission error:", e);
      Alert.alert("Submission Error", "Failed to submit answers.");
    }
  }

  function submit() {
    if (answers.length === 0) return Alert.alert("No answers recorded.");
    if (answers.length !== interview.questions.length) {
      Alert.alert(
        "Incomplete",
        `You recorded ${answers.length}/${interview.questions.length}. Submit anyway?`,
        [
          { text: "Cancel", style: "cancel" },
          { text: "Submit", onPress: submitAnswers },
        ]
      );
      return;
    }
    submitAnswers();
  }

  const getAnswerStatus = index => {
    const answer = answers.find(a => a.qIndex === index);
    if (answer) return "recorded";
    if (recordingStates[index] === "recording") return "recording";
    return "not_recorded";
  };

  const renderQuestion = ({ item, index }) => {
    const status = getAnswerStatus(index);
    const isRecording = status === "recording";
    const isRecorded = status === "recorded";

    return (
      <View style={[styles.questionCard, responsiveStyles.questionCard]}>
        <View style={styles.questionHeader}>
          <Text style={[styles.questionNumber, responsiveStyles.questionNumber]}>
            Q{index + 1}
          </Text>
          <View style={[
            styles.statusIndicator,
            isRecorded && styles.recordedIndicator,
            isRecording && styles.recordingIndicator
          ]}>
            <Text style={[
              styles.statusText,
              isRecorded && styles.recordedText,
              isRecording && styles.recordingText
            ]}>
              {isRecording ? "🔴 REC" : isRecorded ? "✅ RECORDED" : "⏸️ READY"}
            </Text>
          </View>
        </View>
        <Text style={[styles.questionText, responsiveStyles.questionText]}>{item}</Text>

        <View style={styles.controlsContainer}>
          {!isRecording ? (
            <TouchableOpacity
              style={[
                styles.recordButton,
                responsiveStyles.recordButton,
                isRecorded && styles.reRecordButton,
                !isRecordingSupported && styles.disabledButton
              ]}
              onPress={() => startRecording(index)}
              disabled={!isRecordingSupported}
            >
              <Text style={[
                styles.recordButtonText,
                responsiveStyles.recordButtonText,
                isRecorded && styles.reRecordButtonText,
                !isRecordingSupported && styles.disabledButtonText
              ]}>
                {!isRecordingSupported ? "❌ Not Supported" : isRecorded ? "🎤 Re-record" : "🎤 Record Answer"}
              </Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.stopButton, responsiveStyles.stopButton]}
              onPress={stopRecording}
            >
              <Text style={[styles.stopButtonText, responsiveStyles.stopButtonText]}>
                ⏹️ Stop Recording
              </Text>
            </TouchableOpacity>
          )}

          {isRecorded && (
            <TouchableOpacity
              style={[styles.playButton, responsiveStyles.playButton]}
              onPress={() => playRecording(answers.find(a => a.qIndex === index)?.uri)}
            >
              <Text style={[styles.playButtonText, responsiveStyles.playButtonText]}>
                ▶️ Play
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  const responsiveStyles = getResponsiveStyles();
  const recordedCount = answers.length;
  const totalQuestions = interview.questions.length;

  return (
    <SafeAreaView style={[styles.container, responsiveStyles.container]}>
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={[styles.scrollContent, responsiveStyles.scrollContent]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={[styles.content, responsiveStyles.content]}>
            <View style={[styles.header, responsiveStyles.header]}>
              <Text style={[styles.interviewTitle, responsiveStyles.interviewTitle]}>
                🎤 {interview.title}
              </Text>
              <Text style={[styles.progressText, responsiveStyles.progressText]}>
                Progress: {recordedCount}/{totalQuestions}
              </Text>
              {!isRecordingSupported && (
                <Text style={styles.warningText}>
                  ⚠️ Audio recording may not be supported
                </Text>
              )}
            </View>

            <View style={[styles.progressContainer, responsiveStyles.progressContainer]}>
              <View style={[styles.progressBar, { width: `${(recordedCount / totalQuestions) * 100}%` }]} />
            </View>

            <FlatList
              data={interview.questions}
              keyExtractor={(q, i) => String(i)}
              renderItem={renderQuestion}
              contentContainerStyle={styles.flatListContent}
            />

            <TouchableOpacity
              style={[
                styles.submitButton,
                responsiveStyles.submitButton,
                recordedCount === 0 && styles.disabledButton
              ]}
              onPress={submit}
              disabled={recordedCount === 0}
            >
              <Text style={[
                styles.submitButtonText,
                responsiveStyles.submitButtonText,
                recordedCount === 0 && styles.disabledButtonText
              ]}>
                📤 Submit Answers ({recordedCount}/{totalQuestions})
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// Responsive styles
const getResponsiveStyles = () =>
  StyleSheet.create({
    container: { paddingHorizontal: isDesktop ? wp(15) : isTablet ? wp(10) : wp(5) },
    scrollContent: { minHeight: hp(100), paddingVertical: isTablet ? hp(3) : hp(2) },
    content: { maxWidth: isDesktop ? 500 : isTablet ? 450 : wp(90), alignSelf: "center" },
    header: { marginBottom: isTablet ? 24 : 20, alignItems: "center" },
    interviewTitle: { fontSize: isDesktop ? 32 : isTablet ? 28 : isSmallPhone ? 24 : 26, marginBottom: 8 },
    progressText: { fontSize: isDesktop ? 16 : isTablet ? 15 : 14 },
    progressContainer: { height: isTablet ? 8 : 6, backgroundColor: "#334155", borderRadius: 4, marginBottom: 24 },
    questionCard: { paddingHorizontal: 16, paddingVertical: 16, marginBottom: 12 },
    questionNumber: { fontSize: 14 },
    questionText: { fontSize: 14, marginBottom: 12 },
    recordButton: { paddingVertical: 10, paddingHorizontal: 16, marginRight: 10 },
    recordButtonText: { fontSize: 13 },
    stopButton: { paddingVertical: 10, paddingHorizontal: 16 },
    stopButtonText: { fontSize: 13 },
    playButton: { paddingVertical: 8, paddingHorizontal: 12 },
    playButtonText: { fontSize: 12 },
    submitButton: { paddingVertical: 14, marginBottom: 16 },
    submitButtonText: { fontSize: 16 },
  });

// Default styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0F172A" },
  keyboardView: { flex: 1 },
  scrollContent: { flexGrow: 1, justifyContent: "center", alignItems: "center" },
  content: { width: "100%" },
  header: { alignItems: "center" },
  interviewTitle: { color: "#F8FAFC", fontWeight: "700", textAlign: "center" },
  progressText: { color: "#94A3B8", fontWeight: "500" },
  warningText: { color: "#F59E0B", fontWeight: "500", textAlign: "center", marginTop: 4 },
  progressContainer: { backgroundColor: "#334155", borderRadius: 4 },
  progressBar: { height: "100%", backgroundColor: "#10B981", borderRadius: 4 },
  flatListContent: { paddingBottom: 10 },
  questionCard: { backgroundColor: "#1E293B", borderRadius: 16, borderWidth: 1, borderColor: "#334155", marginBottom: 12 },
  questionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  questionNumber: { color: "#3B82F6", fontWeight: "700" },
  statusIndicator: { backgroundColor: "#64748B", borderRadius: 12, paddingHorizontal: 8, paddingVertical: 4 },
  statusText: { color: "#FFFFFF", fontSize: 12, fontWeight: "600" },
  recordedIndicator: { backgroundColor: "#10B981" },
  recordingIndicator: { backgroundColor: "#EF4444" },
  controlsContainer: { flexDirection: "row", alignItems: "center", marginTop: 12 },
  recordButton: { backgroundColor: "#3B82F6", borderRadius: 12, alignItems: "center" },
  recordButtonText: { color: "#FFFFFF", fontWeight: "600" },
  reRecordButton: { backgroundColor: "#F59E0B" },
  reRecordButtonText: { color: "#FFFFFF" },
  stopButton: { backgroundColor: "#EF4444", borderRadius: 12, alignItems: "center" },
  stopButtonText: { color: "#FFFFFF", fontWeight: "600" },
  playButton: { backgroundColor: "#10B981", borderRadius: 12, alignItems: "center" },
  playButtonText: { color: "#FFFFFF", fontWeight: "600" },
  submitButton: { backgroundColor: "#10B981", borderRadius: 16, alignItems: "center" },
  submitButtonText: { color: "#FFFFFF", fontWeight: "600" },
  disabledButton: { backgroundColor: "#64748B" },
  disabledButtonText: { color: "#94A3B8" },
});
